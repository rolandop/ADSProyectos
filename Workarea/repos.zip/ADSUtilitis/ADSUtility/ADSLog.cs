﻿using Confluent.Kafka;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using Confluent.Kafka.Serialization;
using System.Text;
using Newtonsoft.Json;
using ADSUtilities.Util;

namespace ADSLog
{
    public class Log
    {
        private string _topicName;
        
        private static readonly Random rand = new Random();
        private LogLevel level;
        private BookingProducer producer;

        public Log()
        {
            level = new LogLevel {
                Critical = "critical",
                Error = "error",
                Info = "info",
                Warning = "warning"
            };
            this._topicName = "topic";
            producer = new BookingProducer();
        }
        private async Task<object> writeMessage(Object o)
        {
            string message = JsonConvert.SerializeObject(o);
            producer.Produce(message);
            return null;
            
        }

        public async void Error(string parMesagge, Object parObj, string TransactionId = null)
        {
            var error = new LogStructure
            {
                LogLevel = level.Error,
                Application = "app",
                Cuerpo = parObj,
                TransactionId = TransactionId,
                Mesagge = parMesagge,
            };
            await this.writeMessage(error);
        }

        public async void Warning(string parMesagge, Object parObj, string TransactionId = null)
        {
            var error = new LogStructure
            {
                LogLevel = level.Warning,
                Application = "app",
                Cuerpo = parObj,
                TransactionId = TransactionId,
                Mesagge = parMesagge
            };
            await this.writeMessage(error);
        }
        public async  void Info(string parMesagge, Object parObj, string TransactionId = null)
        {
            var error = new LogStructure
            {
                LogLevel = level.Error,
                Application = "app",
                Cuerpo = parObj,
                TransactionId = TransactionId,
                Mesagge = parMesagge
            };
            await this.writeMessage(error);
        }
        
    }
}
