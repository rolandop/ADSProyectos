﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ADSUtilities.Util
{
    public interface IBookingProducer
    {
   void Produce(string message);
    }
}
