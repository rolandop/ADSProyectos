﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ADSAuditsConsumer.DALL.Model
{
    public class Settings
    {
        public string ConnectionString;
        public string Database;
    }
}
