﻿using ADSAuditsConsumer.DALL.Model;
using ADSAuditsConsumer.Model;
using ADSAuditsConsumer.Utils;
using MongoDB.Driver;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;
using System;

namespace ADSAuditsConsumer
{
    class Program
    {
        static void Main(string[] args)
        {
            const string connectionString = "mongodb://localhost:27017";

            // Create a MongoClient object by using the connection string
            var client = new MongoClient(connectionString);

            //Use the MongoClient to access the server
            var database = client.GetDatabase("log");
            var collection = database.GetCollection<LogModel>("Logs");


            var bookingStream = new BookingStream();
            var bookingConsumer = new BookingConsumer(bookingStream, Console.WriteLine);
            var settings = new JsonSerializerSettings
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver()
            };

            bookingStream.Subscribe("Subscriber1", (m) =>
            {
                Console.WriteLine($"Subscriber1 Message : {m.Message}");

                
                var entrada = JsonConvert.DeserializeObject<LogModelIn>(m.Message);
                var oJson = JObject.Parse(JsonConvert.SerializeObject(entrada.Cuerpo));
                var entity = new LogModel {
                    Application = entrada.Application,
                    Cuerpo = oJson.ToString(),
                    LogLevel = entrada.LogLevel,
                    TransactionId = entrada.TransactionId,

                };

                collection.InsertOneAsync(entity);
                   // var id = entity._id;          
            });
            

            bookingConsumer.Listen();
        }
    }
}
