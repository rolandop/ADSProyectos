﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ADSAuditsConsumer.Utils
{

    public class BookingMessage
    {
        public string Message { get; set; }
    }
}
