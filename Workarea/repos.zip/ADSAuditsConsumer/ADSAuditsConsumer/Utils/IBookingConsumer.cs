﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ADSAuditsConsumer.Utils
{
    public interface IBookingConsumer
    {
        void Listen();
    }
}
